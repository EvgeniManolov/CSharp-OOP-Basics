﻿using System;
using System.Collections.Generic;

public class StackOfStrings
{
    private List<string> data;

    public void Push(string item)
    {

    }

    public string Pop()
    {
        return "";
    }

    public string Peek()
    {
        return "";
    }

    public bool isEmpty()
    {
        return true;
    }



}

