﻿namespace MordorsCrueltyPlan.FoodModels
{
    public class HoneyCake : Food
    {
        public HoneyCake()
                : base(5)
        {
        }
    }

}