﻿namespace MordorsCrueltyPlan.MoodModels
{
    public class JavaScript : Mood
    {
    }

}