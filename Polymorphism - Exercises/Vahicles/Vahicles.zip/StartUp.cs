﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vahicles
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var carArgs = Console.ReadLine().Split(new[] { " " }, StringSplitOptions.RemoveEmptyEntries);
            var car = new Car(double.Parse(carArgs[1]), double.Parse(carArgs[2]), double.Parse(carArgs[3]));
            var truckArgs = Console.ReadLine().Split(new[] { " " }, StringSplitOptions.RemoveEmptyEntries);
            var truck = new Truck(double.Parse(truckArgs[1]), double.Parse(truckArgs[2]), double.Parse(carArgs[3]));
            var busArgs = Console.ReadLine().Split(new[] { " " }, StringSplitOptions.RemoveEmptyEntries);
            var bus = new Bus(double.Parse(busArgs[1]), double.Parse(busArgs[2]), double.Parse(busArgs[3]));
            var n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                var cmdArgs = Console.ReadLine().Split(new[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                var cmd = cmdArgs[0];
                var vehicle = cmdArgs[1];
                var numberArg = double.Parse(cmdArgs[2]);
                switch (cmd)
                {
                    case "Drive":
                        switch (vehicle)
                        {
                            case "Car":
                                car.Drive(numberArg);
                                break;
                            case "Truck":
                                truck.Drive(numberArg);
                                break;
                            case "Bus":
                                bus.Drive(numberArg);
                                break;
                        }
                        break;
                    case "DriveEmpty":
                        bus.DriveEmp(numberArg);
                        break;
                    case "Refuel":
                        switch (vehicle)
                        {
                            case "Car":
                                car.Refuel(numberArg);
                                break;
                            case "Truck":
                                truck.Refuel(numberArg);
                                break;
                            case "Bus":
                                bus.Refuel(numberArg);
                                break;

                        }
                        break;
                }
            }

            Console.WriteLine(car.ToString());
            Console.WriteLine(truck.ToString());
            Console.WriteLine(bus.ToString());
        }
    }
}
